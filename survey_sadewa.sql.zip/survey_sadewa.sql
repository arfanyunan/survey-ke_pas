--
-- Database: `survey_sadewa`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `jawaban_survey_ralan`
--

CREATE TABLE `jawaban_survey_ralan` (
  `id` int(5) NOT NULL,
  `tgl_isi` datetime NOT NULL,
  `poli` varchar(20) NOT NULL,
  `nm_dokter` varchar(50) NOT NULL,
  `petugas` varchar(50) NOT NULL,
  `p1` varchar(5) NOT NULL,
  `p2` varchar(5) NOT NULL,
  `p3` varchar(5) NOT NULL,
  `p4` varchar(5) NOT NULL,
  `p5` varchar(5) NOT NULL,
  `saran` varchar(100) NOT NULL,
  `kritik` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `jawaban_survey_ranap`
--

CREATE TABLE `jawaban_survey_ranap` (
  `id` int(5) NOT NULL,
  `tgl_isi` datetime NOT NULL,
  `tgl_ranap` datetime NOT NULL,
  `pasien` varchar(50) NOT NULL,
  `petugas` varchar(50) NOT NULL,
  `bangsal` varchar(20) NOT NULL,
  `p1` varchar(20) NOT NULL,
  `p2` varchar(20) NOT NULL,
  `p3` varchar(20) NOT NULL,
  `p4` varchar(20) NOT NULL,
  `p5` varchar(20) NOT NULL,
  `p6` varchar(50) NOT NULL,
  `p7a` varchar(50) DEFAULT NULL,
  `p7b` varchar(50) DEFAULT NULL,
  `p7c` varchar(50) DEFAULT NULL,
  `p7d` varchar(50) DEFAULT NULL,
  `p8` varchar(50) NOT NULL,
  `saran` varchar(100) NOT NULL,
  `kritik` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id` int(5) NOT NULL,
  `nama` varchar(20) NOT NULL,
  `pass` varchar(20) NOT NULL,
  `role` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `jawaban_survey_ralan`
--
ALTER TABLE `jawaban_survey_ralan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jawaban_survey_ranap`
--
ALTER TABLE `jawaban_survey_ranap`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `jawaban_survey_ralan`
--
ALTER TABLE `jawaban_survey_ralan`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `jawaban_survey_ranap`
--
ALTER TABLE `jawaban_survey_ranap`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
